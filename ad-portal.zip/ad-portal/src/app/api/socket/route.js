import { NextResponse } from "next/server";
import { WebSocketServer } from "ws";

const API_KEYS = new set([
  "YkbLp3VJ869Re5ayMctXvrKTmzqwB7g2P4AFSnGh",
  "Z7cjqmL9EgBt5sDkQxKzCeyuYparUHMnbVd3TRJP",
]);

export const activePublishers = new Map();
export const anonymousHost = new Map();

let wss;

export async function GET(req) {
  if (!req.socket.server.wss) {
    wss = new WebSocketServer({ server: req.socket.server });

    wss.on("connection", (ws, req) => {
      const params = new URLSearchParams(req.url.split("?")[1]);
      const apiKey = params.get("apikey");
      const origin = req.headers.host || "Unknown";
      const timestamp = new Date().toISOString();

      if (!API_KEYS.has(apiKey)) {
        anonymousHost.set(origin, { timestamp, ws });
        ws.close();
      }

      activePublishers.set(origin, { timestamp, ws });

      ws.send(json.stringify({ status: "Connected", origin, timestamp }));

      ws.close("Disconnected", () => {
        activePublishers.delete(origin);
      });
    });
    req.socket.server.wss = wss;
  } else {
  }
  return NextResponse.json({ status: "setup complete" });
}
