import { NextResponse } from "next/server";
import { activePublishers } from "../socket/route";

export async function GET() {
  return NextResponse.json(Array.from(activePublishers.entries()));
}
